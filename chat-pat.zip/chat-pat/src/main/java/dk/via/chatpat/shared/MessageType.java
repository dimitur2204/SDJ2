package dk.via.chatpat.shared;

public class MessageType {
    public static final String SEND_MESSAGE = "SEND_MESSAGE";
    public static final String NEW_CHATTER = "NEW_CHATTER";
    public static final String GET_CHATTERS = "GET_CHATTERS";
    public static final String EXIT = "EXIT";
}
