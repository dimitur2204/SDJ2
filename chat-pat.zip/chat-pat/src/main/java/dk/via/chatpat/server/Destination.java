package dk.via.chatpat.server;

public enum Destination {
    FILE, CONSOLE
}
