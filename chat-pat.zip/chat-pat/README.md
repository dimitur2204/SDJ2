## How to run
1. Import the remoteobserver.jar file to the module.
2. Make sure you are running a Java 17 SDK.
3. Run the ChatServer.java file to start the server.
4. Run the ChatApplication.java file to start a client multiple times.
5. Enter the username and start chatting.